CREATE DATABASE TESTsql
USE TESTsql

CREATE TABLE Region
(	PK_RegID INT PRIMARY KEY,
	FK_RegParentID INT FOREIGN KEY REFERENCES Region(PK_RegID),
	RegName VARCHAR(25));

CREATE TABLE Category
(	PK_CatID INT PRIMARY KEY,
	CatName VARCHAR(50));

CREATE TABLE Product
(	PK_ProdID INT PRIMARY KEY,
	FK_CatID INT FOREIGN KEY REFERENCES Category(PK_CatID),
	ProdName VARCHAR(50),
	ProdCost DECIMAL (6,2),
	Flagstatus	BIT);

CREATE TABLE Sales
(	PK_SaleID	VARCHAR (8) PRIMARY KEY,
	FK_ProdID	INT FOREIGN KEY REFERENCES Product(PK_ProdID),
	OrderDate	DATE,
	Orderqty	INT,
	UnitPrice	DECIMAL(7,2),
	OrderAmount	DECIMAL (10,2),
	FK_RegID	INT FOREIGN KEY REFERENCES Region(PK_RegID));


INSERT INTO Category
(	PK_CatID,
	CatName)
			  VALUES	(1,'Cargo'),
						(2,'City Action'),
						(3,'Free Time'),
						(4, 'Far West'),
						(5,'Knights'),
						(6,'History'),
						(7,'City Life'),
						(8,'Dollhouse');



INSERT INTO Product
(PK_ProdID,
	FK_CatID,
	ProdName,
	ProdCost,
	Flagstatus)
					VALUES	(70771,1,'Motrice con container', 26,1),	
							(70772,1,'Operai con muletto', 12.50,1),
							(70775,1,'Controllo merci',4.32,0),
							(7350,1,'Motore subacqueo',2.87,1), 
							(5131,1,'Barca dei pescatori',6.71,0),
							(70769,1,'Nave da carico con container',42.83,0),
							(70770,1,'Rampa di carico mobile', 31.99,0),
							(70442,1, 'Carrello per carico e scarico Gru', 24.89,1),
							(70443,1,'Grande Gru',36.79,1),
 							(70444,1,'Camion con due cassoni',22.49,1),
 							(9898,1,'Trasporto casa mobile', 19.99,1),
							(4041,1,'Rampa di carico',16.70,1),
							(6599,1,'Bulldozer',8.19,1), 
							(9845,2,'Gommone dei Vigili del Fuoco', 8.15,1),
							(5398,2,'Unit� mobile dei Vigili del Fuoco',5.69,1),
							(7485,2,'Rimorchio per i pompieri',11.43,1),
							(70570,2,'Quad della polizia con ladro',9.88,1),
							(70573,2,'Poliziotto in bici e borseggiatore',5.09,1),
							(6502, 2,'Capo della Polizia',1.39,1) ,
							(7446,2,'Cassaforte',4.19,1),   
							(7445,2,'Proiettore di luce',6.99,1),  
							(6922,2,'Trasporto cavalli della Polizia',8.99,1),
							(6503,2,'Ampliamento Stazione di polizia con allarme',7.59,1), 
							(6919,2,'Stazione della Polizia con prigione', 28.29,1),
							(1030,3,'Street Sport Calcio',3.09,1),
							(1029,3,'Street Sport Basket',7.49,1),
							(70960,3,'Street Sport Park',15.64,1), 
							(4239,3,'Teatrino Marionette portatile',22.52,0),
							(5248,4,'Assalto alla diligenza',12.76,1), 
							(6271,4,'Capo Indiano',1.49,1), 
							(1003,4,'Sceriffo',3.49,0),
 							(6322,4,'Famiglia di indiani',3.99,1), 
							(6278,4,'Cowboys con cowgirl',2.99,1),
 							(6272,4,'Indiani sioux',2.99,1),
							(71351,4,'Waterfall Ranch',45.20,1),
							(1036,4,'Estensione stalla Waterfall Ranch',16.80, 1),
							(1039,4,'Palizzate',2.99,1), 
							(1037,4,'Estensione box Waterfall Ranch',14.05,1), 
							(1038,4,'Estensione recinto Waterfall Ranch',1.99,1), 
							(70944,4,'Fortino western',35.99,1),
							(1023,4,'Nascondiglio dei banditi',8.99,1),
							(1024,4,'Grande negozio western',29.99,1),
							(70955,5,'Bottega medievale',29.50,1),
							(70958,5,'Abitazione medievale',19.69,1),
							(70956,5,'Officina del Fabbro',29.99,1),
							(70953,5,'Prigione medievale con torre',23.99,1), 
							(70954,5,'Forno medievale',19.99 ,1),
							(6492,6,'Famiglia egizia',3.99, 1),
							(6493,6,'Famiglia antica Roma',3.99,1),
							(6590,6,'I 3 Gladiatori',2.99,1),
							(6488,6,'I 3 soldati egiziani',2.99,1),  
							(64903,6,'I Legionari',2.99,1), 
							(9891,6,'Nave vichinga',13.99,1),
							(9892,6,'Capo vichingo',1.49,1),
							(9893,6,'I 3 vichinghi',3.99,1),
							(4433,6,'Fortezza vichinga',23.99,1), 
							(71327,7,'Grande scuola',79.75,1),  
							(1032,7,'Piano addizionale aula di arte',15.99,1),
							(1035,7,'Aula di chimica',5.99,1),
							(1033,7,'Ampliamento Grande scuola',8.99,0),
							(1034,7,'Aula di storia',5.99,0),
							(5575,7,'Piscina con terrazzo',12.99,1),
							(5586,7,'D�pendance degli ospiti',23.59,1),
							(6530,7,'Set di personaggi',3.99,1),
							(5574,7,'Lussuosa Villa arredata',30.99, 1),
							(1025,7,'Panetteria',12.99,1),
							(1026,7,'Baby Store',12.99,1),
							(1028,7,'Ufficio',15.99,  1),
							(9868,7,'Camera dei pirati',5.99,0), 
							(9869,7,'Camera delle principesse',5.99,0),
							(4318,7,'Garage',11.99,1),
							(6558,7,'Capanno degli attrezzi con orto',9.99,1),
							(70890,8,'Grande casa delle bambole',89.88,0),
							(70971,8,'Camera da letto',11.88,1),  
							(70970,8,'Cucina',12.99,1),  
							(70896,8,'Terrazza arredata',12.99,1),
							(70892,8,'Cameretta',11.99,1),
							(70893,8,'Cameretta del beb�',10.99,0),
							(70894,8,'Soggiorno',10.99,1),
							(70897,8,'Stanza del camino',10.99,1),
							(70895,8,'Bagno',9.99,1);




INSERT INTO Region
(	PK_RegID,
	FK_RegParentID,
	RegName)
			VALUES	(1,NULL,'Europe'),
					(2,NULL,'United States'),
					(3,NULL,'Asia'),
					(4,NULL,'South America'),
					(5,NULL,'Australia'),
					(6,1,'Italy'),
					(7,1,'Portugal'),
					(8,1,'France'),
					(9,1,'Spain'),
					(10,4,'Brasil'),											
					(11, 2,'California'),
					(12, 2,'Florida'), 	
					(13, 2,'Arizona'),											
					(14, 2,'Massachusetts'),										
					(15,2,'New York'),											
					(16,3,'China'),											
					(17,3,'Japan'),											
					(18,3,'Singapur'),											
					(19,3,'South Korea'),										
					(20,3,'Qatar'),
					(21,4,'Brasil'),
					(22,4,'Argentina'),
					(23,4,'Chile'),
					(24,4,'Uruguay'),
					(25,5,'Tasmania'),											
					(26,5,'Queensland'),	
					(27,5,'Victoria');

INSERT INTO Sales

(	PK_SaleID,
	FK_ProdID,
	OrderDate,
	Orderqty,
	Unitprice,
	OrderAmount,
	FK_RegID)
					
VALUES

(21000011,4041,'2021-07-12',3,79.99,239.97,8),
(24000015,70772,'2024-01-07',2,34.99,69.98,16),
(23001215,70771,'2023-12-09',1,79.99,79.99,20),
(23001197,70772,'2023-11-23',1,34.99,34.99, 8),
(22000098,70775,'2022-03-12',3,12.99,38.97,17),
(23000254,7350,'2023-05-20',15,7.99,119.85,9),
(23001169,5131,'2023-11-05',4,19.99,79.96,11),
(23001224,70769,'2023-12-11',9,119.99,1079.91,13),
(22001357,70770,'2022-12-01',3,99.99,299.97,26),
(23000841,70442,'2023-09-18',2,84.99,169.98,23),
(23000899,70443,'2023-10-22',6,129.99,779.94,14),
(23000598,70444,'2023-07-15',1,72.99,72.99,21),
(24000098,9898,'2024-01-26',1,69.99,69.99,10),
(23000075,4041,'2023-02-01',4,49.99,199.96,18),
(23000786,6599,'2023-07-24',10,24.99,249.90, 22),
(22000984,9845,'2022-10-16',2, 24.99,49.98,25),
(23001390,7485,'2023-12-05',5,29.99,149.95,6),
(22000006,4041,'2022-07-12',3,79.99,239.97,8),
(22000015,70772,'2022-01-07',2, 34.99,69.98,16),
(21001215,70771,'2021-12-09',1, 79.99,79.99,20),
(21001197,70772,'2021-11-23',1,34.99,34.99, 8),
(21000098,70775,'2021-03-12',3,12.99,38.97,17),
(22000250,7350,'2022-05-20',15,7.99,119.85,9),
(22001166,5131,'2022-11-01',4,19.99,79.96,11),
(21001224,70769,'2021-12-11',9,119.99,1079.91,13),
(23013587,70770,'2023-12-01',3,99.99,299.97,26),
(22000847,70442,'2022-09-18',2,84.99,169.98,23),
(21000899,70443,'2021-10-22',6, 129.99,779.94,14),
(21000592,70444,'2021-07-15',1,72.99,72.99,21),
(22000091,9898,'2022-01-26',1,69.99,69.99,10),
(22000077,4041,'2022-02-01',4,49.99,199.96,18),
(21000786,6599,'2021-07-24',10,24.99,249.90,22),
(21000984,9845,'2021-10-16',2,24.99,49.98,25),
(22000254,5398,'2022-03-05',12,14.99,179.88,21),
(21001397,7485,'2021-12-05',5,29.99,149.95,6),
(22000501,5586,'2022-06-12',7,59.99,419.93,8),
(21000022,1030,'2021-01-12',3,10.99,32.97,25), 
(23001366,1029,'2023-12-02',8,16.99,135.92,19),
(23001091,70960,'2023-10-13',1,39.99,39.99,10), 
(21000015,4239,'2021-01-06',2, 59.99,119.98,13),
(23000019,5248,'2023-01-05',2, 34.99,69.98,12),
(21000398,6271,'2021-03-30',15,3.49, 52.35,25),
(23000111,71351,'2023-04-04',3,129.99,389.97,11),  
(23001167,6922,'2023-11-01',4,19.99,79.96,22),
(22001169,1023,'2023-12-01',4,17.99,71.96,15),
(23001356,70944,'2023-11-30',3,99.99,299.97,16),
(23001214,1024,'2023-12-08',1, 69.99,69.99,10),
(23001210,70953,'2023-12-07',3, 59.99,179.97,18),
(22000221,7350,'2022-05-20',15,7.99,119.85,14),
(21001165,6503,'2023-11-01',4,19.99,79.96,22), 
(23000033,6558,'2023-01-15',3,22.99,68.97,16),
(22001222,1024,'2022-12-11',9,22.99,206.91,11),
(23001354,1003,'2023-12-01',3,9.99,29.97,16),
(21000747,6278,'2021-09-18',2,8.99,16.98,24),
(23000999,6272,'2023-11-03',6, 8.99,53.94,16),
(23000632,6272,'2023-07-31',10,8.99,89.90,15),
(21000137,1037,'2021-01-26',10,24.99,249.90,6),
(23000175,1037,'2023-02-01',4,24.99,99.96,8),
(22000461,1038,'2023-04-24',10,9.99,99.90, 19),
(21000971,1038,'2021-10-16',2, 9.99,19.98,17),
(21000253,70955,'2021-03-05',10,59.99,559.90,7),
(23001222,70958,'2023-11-18',5,49.99,249.95,7),
(22000647,70958,'2022-06-09',3,49.99,149.97,8),
(23001415,70954,'2023-12-22',10,49.99,499.90,21),
(23001183,6492,'2023-11-15',12,10.99,131.88, 26),
(22001181,6492,'2022-11-13',12,10.99,131.88, 18),
(23000091,6493,'2023-03-12',3,10.99,32.97,17),
(22000251,6590,'2022-05-19',15,8.99,134.85,22),
(21001220,6590,'2021-12-10',9,8.99,80.91,12),
(23000437,64903,'2023-04-01',9,8.99,81.91,21),
(22000830,9891,'2022-07-28',20,29.99,599.80,20),
(23000847,9892,'2023-09-16',20,3.49,69.80,23),
(23000699,70895,'2021-07-01',6, 19.99,119.94,10),
(23000795,70897,'2023-08-03',10,19.99,199.90,11),
(21000198,4433,'2021-02-05',7,19.99,139.93,16),
(21000073,71327,'2021-02-01',8,19.99,159.96,12),
(23000688,5575,'2023-07-10',6,24.99,149.94,6),
(22000974,1032,'2022-10-06',2, 29.99,59.98,20),
(23000944,1032,'2023-10-01',5, 29.99,149.95,6),
(22000234,1035,'2022-03-01',12,14.99,179.88,17),
(23001397,5574,'2023-12-05',5,89.99,449.95,6),
(22001342,5574,'2022-12-12',5,89.99,449.95,23),
(21000103,5574,'2021-03-12',3,89.99,269.97,15),
(23000102,1025,'2023-02-01',10,24.99, 249.90,17),
(23001058,1028,'2023-10-20',4,27.99,107.96,19),
(22001013,1028,'2022-10-20',2,27.99,55.98,25),
(22000879,4318,'2022-10-19',6, 29.99,179.94,14),
(23000568,4318,'2023-07-14',10,29.99,290.90,21),
(23000112,70971,'2022-01-23',9,24.99,224.91,9),
(22000045,4041,'2022-02-01',4,24.99,99.96,15),
(21000776,70970,'2021-07-24',10,29.99,299.90,7),
(21000974,70970,'2021-10-16',2, 29.99,59.98,6),
(22000241,70970,'2022-03-05',12,29.99, 359.88,17),
(23000106, 70896,'2023-02-04',3,22.99,68.97,9),
(23001372, 70896,'2023-12-02',5,29.99,149.95,16),
(23001243,70892,'2023-11-12',5,19.99,99.95,25),
(22001005, 70892,'2022-10-22',2,19.99,39.98,21),
(21000051,70893,'2021-01-17',5,19.99,99.95,19),
(23001059, 70893,'2023-10-13',4,19.99,79.96,7);












SELECT *
FROM Product
SELECT *
FROM Category
SELECT *
FROM Region
SELECT *
FROM Sales

--1) Verificare che i campi definiti come PK siano univoci. 
SELECT COUNT(*)
FROM Product
GROUP BY PK_ProdID
HAVING COUNT(*)>1;

SELECT COUNT(*)
FROM Category
GROUP BY PK_CatID
HAVING COUNT(*)>1;

SELECT COUNT(*)
FROM Sales
GROUP BY PK_SaleID
HAVING COUNT(*)>1;

SELECT COUNT(*)
FROM Region
GROUP BY PK_RegID
HAVING COUNT(*)>1;

/*2)	Esporre l�elenco delle transazioni indicando nel result set il codice documento,
la data, il nome del prodotto, la categoria del prodotto, il nome dello stato,
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione
che siano passati pi� di 180 giorni dalla data vendita o meno(>180 -> True, <= 180 -> False)*/


CREATE VIEW Nm_AREA AS
SELECT	Reg1.RegName AS StateName,
		Reg2.RegName AS SalesArea,
		Reg1.PK_RegID
FROM Region AS Reg1
JOIN Region as Reg2
ON Reg1.FK_RegParentID = Reg2.PK_RegID


SELECT	PK_SaleID AS SalesNr,
		OrderDate AS SalesDate,	
		ProdName AS ProductName, 	
		CatName AS CategoryName,
		StateName,
		Salesarea,
		CASE WHEN  DATEDIFF(day,OrderDate,GETDATE()) >180 
		THEN 'true'
		ELSE 'false' END AS Flagday
FROM Sales
JOIN Product 
ON FK_ProdID = PK_ProdID
JOIN Category
ON FK_CatID = PK_CatID
JOIN  dbo.Nm_AREA 
ON FK_RegID = PK_RegID



-- 3)Esporre l'elenco dei soli prodotti venduti e per ognuno di essi il fatturato totale per anno.

SELECT	YEAR(OrderDate) as SalesYear,	
		ProdName as ProductName,
		SUM(OrderAmount)as TotalAmount
FROM Sales
JOIN Product
ON FK_ProdID=PK_ProdID
Group by  YEAR(OrderDate), ProdName


--4)Esporre il fatturato totale per stato e per anno ordina per data e fatturato decrescente

SELECT	YEAR(OrderDate) as SalesYear,	
		SUM(OrderAmount) as TotalAmount, 
		StateName
FROM Sales
JOIN dbo.Nm_AREA
ON FK_RegID = PK_RegID 
GROUP BY YEAR(OrderDate),dbo.Nm_AREA.StateName
ORDER BY YEAR(OrderDate), TotalAmount DESC


--5)Qual'� la categoria maggiormente richiesta dal mercato?

SELECT TOP 1 COUNT(fk_catID) , 
				CatName
FROM Sales
JOIN Product AS p
ON FK_ProdID=PK_ProdID
JOIN Category AS c
ON FK_CatID=PK_CatID
GROUP BY FK_CatID, CatName
ORDER BY COUNT(fk_catID)  DESC


--6)Ci sono Prodotti invenduti?
-- Prima soluzione

SELECT	PK_ProdID,
		ProdName
FROM Sales
RIGHT JOIN Product
ON FK_ProdID=PK_ProdID
WHERE PK_SaleID IS NULL

-- Seconda soluzione

SELECT	PK_ProdID,	
		ProdName
FROM Product
WHERE PK_ProdID NOT IN (SELECT FK_ProdID 
						FROM Sales)


-- 7)Esporre la lista dei prodotti venduti con la rispettiva ultima data di vendita (pi� recente).

SELECT	s1.FK_ProdID,p.ProdName,
		MAX(OrderDate)as Datarecente

FROM Sales as S1
JOIN Product as p
ON s1.FK_ProdID = p.PK_ProdID
WHERE  s1.FK_ProdID IN (SELECT s2.FK_ProdID
						FROM Sales as s2)
GROUP BY S1.FK_ProdID, p.ProdName

--8)Crea una vista denormalizzata delle informazioni utili sui prodotti

CREATE VIEW NM_Productdenorm AS

(SELECT	PK_ProdID AS ProductCode, 
		ProdName AS ProductName,			
		CatName AS CategoryName,
		ProdCost AS ProductCost
FROM Product
JOIN Category
ON FK_CatID=PK_CatID)


-- 9) Crea una vista denormalizzata in modo da esporre le informazioni geografiche 

CREATE VIEW NM_AreaDenorm AS
(SELECT	Reg1.RegName AS StateName,
		Reg2.RegName AS SalesArea,
		Reg1.PK_RegID,
		Reg1.FK_RegParentID
FROM Region AS Reg1
LEFT OUTER JOIN Region as Reg2
ON Reg1.FK_RegParentID = Reg2.PK_RegID)



-- THE END-THE END 


/* Questa invece � una visualizzazione denormalizzata della tabella Vendite 
con relativi stati e aree di vendita, nome del prodotto e costo ;0)) */
SELECT	PK_SaleID AS SalesNr,
		FK_ProdID AS ProductCode,
		ProdName AS ProductName,
		ProdCost,
		UnitPrice,
		OrderDate,
		Orderqty,
		OrderAmount AS TotalAmount,
		StateName,
		SalesArea
		
FROM Sales
JOIN dbo.Nm_AREA
ON FK_RegID = PK_RegID
JOIN Product
ON FK_ProdID=PK_ProdID

